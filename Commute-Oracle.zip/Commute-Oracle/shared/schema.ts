
import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const queries = pgTable("queries", {
  id: serial("id").primaryKey(),
  origin: text("origin").notNull(),
  results: jsonb("results").notNull(),
  createdAt: text("created_at").default("NOW()"),
});

export const insertQuerySchema = createInsertSchema(queries).pick({
  origin: true,
});

export type CommuteResult = {
  destination: string;
  timeOfDay: string;
  optimistic: number;
  pessimistic: number;
  surfaceMiles: number;
  highwayMiles: number;
  realHigh: number;
  realLow: number;
};

export type QueryResponse = {
  origin: string;
  data: CommuteResult[];
};

export const apiSchema = {
  commute: {
    calculate: {
      input: z.object({
        origin: z.string().min(1, "Origin is required"),
      }),
    }
  }
};
