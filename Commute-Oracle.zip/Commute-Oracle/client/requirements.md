## Packages
framer-motion | For smooth transitions and entry animations
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
The application calculates commute times using a backend API that interfaces with Google Maps.
Data visualization is minimal text/table based as requested.
Clean minimal aesthetic.
