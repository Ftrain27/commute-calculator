import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCalculateCommute } from "@/hooks/use-commute";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ResultCard } from "@/components/ResultCard";
import { Loader2, Search, MapPin, Copy, Check } from "lucide-react";
import { type CommuteResult } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

const formSchema = z.object({
  origin: z.string().min(3, "Please enter a valid origin address"),
});

export default function Home() {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      origin: "",
    },
  });

  const { mutate, isPending, data, error } = useCalculateCommute();

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    mutate(values);
  };

  // Group results by destination for display
  const groupedResults = data?.data.reduce((acc, curr) => {
    if (!acc[curr.destination]) {
      acc[curr.destination] = [];
    }
    acc[curr.destination].push(curr);
    return acc;
  }, {} as Record<string, CommuteResult[]>) || {};

  const handleCopy = () => {
    if (!data) return;

    const text = data.data.map(r => 
      `${r.destination} (${r.timeOfDay})\n` +
      `Range: ${Math.round(r.realLow)}-${Math.round(r.realHigh)} min\n` +
      `Stats: ${r.highwayMiles.toFixed(1)}mi Hwy, ${r.surfaceMiles.toFixed(1)}mi Surface`
    ).join("\n\n");

    navigator.clipboard.writeText(`Commute Analysis from: ${data.origin}\n\n${text}`);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      description: "Analysis results are ready to paste.",
    });
    
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 lg:p-12 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-2 mb-12">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">
            Commute Analyzer
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Calculate accurate commute times separating highway vs. surface miles using historical traffic data.
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-2xl shadow-lg shadow-black/5 p-6 md:p-8 border border-border/50">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col md:flex-row gap-4 items-end">
              <FormField
                control={form.control}
                name="origin"
                render={({ field }) => (
                  <FormItem className="flex-1 w-full">
                    <FormLabel className="text-foreground font-semibold ml-1">Starting Point</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                        <Input 
                          placeholder="e.g. 123 Main St, Orlando, FL" 
                          className="pl-10 h-12 text-lg bg-secondary/20 border-border/50 focus:bg-background transition-all" 
                          {...field} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                disabled={isPending}
                className="h-12 px-8 text-lg font-medium shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all min-w-[140px]"
              >
                {isPending ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Wait...
                  </>
                ) : (
                  <>
                    Calculate
                    <Search className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </form>
          </Form>
        </div>

        {/* Error State */}
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-destructive/10 text-destructive p-4 rounded-xl border border-destructive/20 text-center"
          >
            <p className="font-medium">Error calculating commute</p>
            <p className="text-sm opacity-90">{error.message}</p>
          </motion.div>
        )}

        {/* Results */}
        <AnimatePresence>
          {data && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-border pb-4">
                <div>
                  <h2 className="text-xl font-bold">Analysis Results</h2>
                  <p className="text-muted-foreground text-sm">From: <span className="text-foreground font-medium">{data.origin}</span></p>
                </div>
                <Button 
                  variant="outline" 
                  onClick={handleCopy}
                  className="gap-2 border-primary/20 hover:bg-primary/5 hover:text-primary transition-colors"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? "Copied!" : "Copy Summary"}
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {Object.entries(groupedResults).map(([destination, results]) => (
                  <div className="lg:col-span-2 xl:col-span-1" key={destination}>
                    <ResultCard destination={destination} results={results} />
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
