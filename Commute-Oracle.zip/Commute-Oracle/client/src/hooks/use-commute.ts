import { useMutation } from "@tanstack/react-query";
import { api, type apiSchema } from "@shared/routes";
import { z } from "zod";

type CalculateCommuteInput = z.infer<typeof api.commute.calculate.input>;
type CalculateCommuteResponse = z.infer<typeof api.commute.calculate.responses[200]>;

export function useCalculateCommute() {
  return useMutation({
    mutationFn: async (data: CalculateCommuteInput) => {
      const res = await fetch(api.commute.calculate.path, {
        method: api.commute.calculate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        throw new Error("Failed to calculate commute times. Please check the origin and try again.");
      }
      
      const json = await res.json();
      return api.commute.calculate.responses[200].parse(json);
    },
  });
}
