
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import axios from "axios";

const DESTINATIONS = [
  "Disney’s Typhoon Lagoon Water Park, FL",
  "1317 Osceola Pkwy, Kissimmee, FL 34744", // Harbor Freight
  "1743 S Orange Ave STE 102, Orlando, FL 32806" // Surterra
];

const TARGET_TIMES = [
  { label: "7:30 AM", hour: 7, minute: 30 },
  { label: "12:00 PM", hour: 12, minute: 0 },
  { label: "6:00 PM", hour: 18, minute: 0 }
];

const HIGHWAY_INDICATORS = ["i-", "us-", "sr-", "state road", "toll", "express", "turnpike"];

function getNextValidDeparture(hour: number, minute: number): Date {
  const date = new Date();
  date.setHours(hour, minute, 0, 0);

  // If the time already passed today, move to tomorrow
  if (date.getTime() <= Date.now()) {
    date.setDate(date.getDate() + 1);
    date.setHours(hour, minute, 0, 0);
  }

  return date;
}

async function getRouteData(origin: string, destination: string, departureTime: Date) {
  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  if (!apiKey) throw new Error("Google Maps API Key not configured");

  // Query Directions API
  // traffic_model=pessimistic and optimistic requires departure_time in future
  const baseUrl = "https://maps.googleapis.com/maps/api/directions/json";
  
  // We need two calls to get distinct optimistic and pessimistic values effectively,
  // or we can just rely on one call if we want a specific model. 
  // However, the prompt asks for both "optimistic" and "pessimistic" times.
  // The API returns 'duration_in_traffic' based on the traffic_model.
  // So we need TWO calls per route per time: one for optimistic, one for pessimistic.
  
  const [optRes, pessRes] = await Promise.all([
    axios.get(baseUrl, {
      params: {
        origin,
        destination,
        key: apiKey,
        departure_time: Math.floor(departureTime.getTime() / 1000),
        traffic_model: 'optimistic'
      }
    }),
    axios.get(baseUrl, {
      params: {
        origin,
        destination,
        key: apiKey,
        departure_time: Math.floor(departureTime.getTime() / 1000),
        traffic_model: 'pessimistic'
      }
    })
  ]);

  const optRoute = optRes.data.routes[0];
  const pessRoute = pessRes.data.routes[0];

  if (!optRoute || !pessRoute) {
    throw new Error(`No route found for ${destination}`);
  }

  const leg = optRoute.legs[0]; // Use optimistic route for distance/steps analysis
  const optimisticTime = leg.duration_in_traffic ? leg.duration_in_traffic.value / 60 : leg.duration.value / 60;
  
  const pessLeg = pessRoute.legs[0];
  const pessimisticTime = pessLeg.duration_in_traffic ? pessLeg.duration_in_traffic.value / 60 : pessLeg.duration.value / 60;

  // Calculate highway vs surface miles
  let highwayMeters = 0;
  let surfaceMeters = 0;

  leg.steps.forEach((step: any) => {
    const instructions = (step.html_instructions || "").toLowerCase();
    const distance = step.distance.value; // in meters

    const isHighway = HIGHWAY_INDICATORS.some(indicator => instructions.includes(indicator));
    
    if (isHighway) {
      highwayMeters += distance;
    } else {
      surfaceMeters += distance;
    }
  });

  const highwayMiles = highwayMeters * 0.000621371;
  const surfaceMiles = surfaceMeters * 0.000621371;

  // Equations
  // Real High = (3.14 x surface miles)+(1.7 x Highway miles)
  // Real Low = optimistic + (0.6 x (pessimistic - optimistic))
  
  const realHigh = (3.14 * surfaceMiles) + (1.7 * highwayMiles);
  const realLow = optimisticTime + (0.6 * (pessimisticTime - optimisticTime));

  return {
    optimistic: optimisticTime,
    pessimistic: pessimisticTime,
    surfaceMiles,
    highwayMiles,
    realHigh,
    realLow
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.commute.calculate.path, async (req, res) => {
    try {
      const { origin } = api.commute.calculate.input.parse(req.body);
      
      const results = [];

      // Loop through destinations and times
      // Note: This might be slow. 3 destinations * 3 times = 9 combinations.
      // Each combination needs 2 API calls (opt/pess) = 18 API calls total.
      // We should run them in parallel as much as possible, but be mindful of rate limits.
      // With a provided key, we assume standard limits.
      
      for (const dest of DESTINATIONS) {
        for (const time of TARGET_TIMES) {
          const departureDate = getNextValidDeparture(time.hour, time.minute);          
          try {
            const data = await getRouteData(origin, dest, departureDate);
            console.log(
              "ROUTE OK",
              dest,
              time.label,
              "opt:",
              data.optimistic.toFixed(1),
              "pess:",
              data.pessimistic.toFixed(1)
            );
            results.push({
              destination: dest,
              timeOfDay: time.label,
              ...data
            });
          } catch (error) {
            console.error(`Error fetching data for ${dest} at ${time.label}:`, error);
            // Push a placeholder or error state if needed, or just skip
          }
        }
      }

      await storage.logQuery(origin, results);

      res.json({
        origin,
        data: results
      });

    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error(err);
      res.status(500).json({ message: "Failed to calculate commute times" });
    }
  });

  return httpServer;
}
