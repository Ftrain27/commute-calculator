import { type CommuteResult } from "@shared/schema";
import { Clock, Car, Map, TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface ResultCardProps {
  destination: string;
  results: CommuteResult[];
}

export function ResultCard({ destination, results }: ResultCardProps) {
  // We assume results are sorted by time or we can display them in a grid
  // The backend returns a flat list, but we are grouping by destination in the parent
  // So 'results' here are all for THIS destination at different times.

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-border/50 overflow-hidden animate-in">
      <div className="bg-secondary/30 px-6 py-4 border-b border-border/50 flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg text-primary">
          <Map className="w-5 h-5" />
        </div>
        <h3 className="text-lg font-bold text-foreground">{destination}</h3>
      </div>
      
      <div className="divide-y divide-border/50">
        {results.map((result, idx) => (
          <div key={idx} className="p-6 hover:bg-muted/20 transition-colors">
            <div className="flex items-center gap-2 mb-4 text-sm font-medium text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>{result.timeOfDay}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Range Stats */}
              <div className="space-y-3">
                <div className="flex justify-between items-end">
                  <span className="text-sm text-muted-foreground">Real Range</span>
                  <span className="text-2xl font-mono font-bold text-primary">
                    {Math.round(result.realLow)} - {Math.round(result.realHigh)} <span className="text-sm font-sans text-muted-foreground font-normal">min</span>
                  </span>
                </div>
                
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden flex">
                  {/* Visual representation of range relative to max possible (arbitrary scale for visual) */}
                  <div 
                    className="h-full bg-primary/20" 
                    style={{ width: `${(result.realLow / 120) * 100}%` }} 
                  />
                  <div 
                    className="h-full bg-primary" 
                    style={{ width: `${((result.realHigh - result.realLow) / 120) * 100}%` }} 
                  />
                </div>

                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <div className="flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" />
                    Opt: {Math.round(result.optimistic)}m
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    Pess: {Math.round(result.pessimistic)}m
                  </div>
                </div>
              </div>

              {/* Distance Stats */}
              <div className="flex flex-col justify-center space-y-2 text-sm">
                <div className="flex justify-between items-center p-2 rounded-lg bg-secondary/50">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Car className="w-4 h-4" />
                    <span>Highway</span>
                  </div>
                  <span className="font-mono font-medium">{result.highwayMiles.toFixed(1)} mi</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-secondary/50">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Map className="w-4 h-4" />
                    <span>Surface</span>
                  </div>
                  <span className="font-mono font-medium">{result.surfaceMiles.toFixed(1)} mi</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
