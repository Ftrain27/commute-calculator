
import { z } from 'zod';
import { apiSchema } from './schema';

export const api = {
  commute: {
    calculate: {
      method: 'POST' as const,
      path: '/api/commute',
      input: apiSchema.commute.calculate.input,
      responses: {
        200: z.object({
          origin: z.string(),
          data: z.array(z.object({
            destination: z.string(),
            timeOfDay: z.string(),
            optimistic: z.number(),
            pessimistic: z.number(),
            surfaceMiles: z.number(),
            highwayMiles: z.number(),
            realHigh: z.number(),
            realLow: z.number(),
          }))
        })
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
