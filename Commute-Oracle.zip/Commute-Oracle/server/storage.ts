
import { db } from "./db";
import { queries } from "@shared/schema";

export interface IStorage {
  // We don't strictly need to store history for this barebones app, 
  // but it's good practice to have the interface ready.
  logQuery(origin: string, results: any): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async logQuery(origin: string, results: any): Promise<void> {
    await db.insert(queries).values({
      origin,
      results,
    });
  }
}

export const storage = new DatabaseStorage();
